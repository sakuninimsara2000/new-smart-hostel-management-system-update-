// ======= USE SAME MOCK DATA AS DASHBOARD =======
const MOCK_STUDENTS = [
    { id: 1, name: 'Kasun Perera', universityId: 'HS/2022/19628', roomNumber: '01', status: 'Active', attendance: [
        { date: '2026-01-20', checkIn: '08:30', checkOut: '18:45', reason: 'Regular' },
        { date: '2026-01-21', checkIn: '08:35', checkOut: '18:50', reason: 'Regular' }
    ]},
];

// ======= SESSION =======
function getStudentSession() {
    return sessionStorage.getItem('studentId') || 1; // default to mock
}

let currentStudent = null;

function loadStudentAttendance() {
    const studentId = getStudentSession();
    currentStudent = MOCK_STUDENTS.find(s => s.id == studentId) || MOCK_STUDENTS[0];
    updateAttendanceUI();
}

function updateAttendanceUI() {
    document.getElementById('studentName').textContent = currentStudent.name;
    document.getElementById('universityId').textContent = currentStudent.universityId;
    document.getElementById('roomNumberDisplay').textContent = currentStudent.roomNumber;
    document.getElementById('attendanceStatus').textContent = currentStudent.status;

    // Today's attendance
    const today = currentStudent.attendance[currentStudent.attendance.length-1];
    document.getElementById('todayCheckin').textContent = today.checkIn;
    document.getElementById('todayCheckout').textContent = today.checkOut;

    // Attendance history
    const tbody = document.getElementById('attendanceHistory');
    tbody.innerHTML = '';
    currentStudent.attendance.forEach(record => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${record.date}</td><td>${record.checkIn}</td><td>${record.checkOut}</td><td>${record.reason}</td>`;
        tbody.appendChild(tr);
    });
}

// Logout
document.getElementById('logoutBtn').addEventListener('click', () => {
    sessionStorage.clear();
    alert('Logged out!');
});

// Init
document.addEventListener('DOMContentLoaded', loadStudentAttendance);
