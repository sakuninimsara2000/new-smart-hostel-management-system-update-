// ==========================================
// DATABASE CONFIGURATION
// ==========================================
const DB_CONFIG = {
    apiUrl: 'http://your-api-endpoint.com/api',
    studentId: null,
    endpoints: {
        getRoomDetails: '/room/details',
        getRoomFacilities: '/room/facilities',
        logout: '/auth/logout'
    }
};

// ==========================================
// ROOM DATA STORAGE
// ==========================================
let currentRoomData = {
    studentId: null,
    roomNumber: null,
    block: null,
    floor: null,
    bedNumber: null,
    roomType: null,
    capacity: null,
    occupied: null,
    occupancy: null,
    status: null,
    facilities: []
};

// ==========================================
// DOM ELEMENTS
// ==========================================
const elements = {
    // Navigation
    navDashboard: document.getElementById('nav-dashboard'),
    navAttendance: document.getElementById('nav-attendance'),
    navRoom: document.getElementById('nav-room'),
    navSetting: document.getElementById('nav-setting'),
    logoutBtn: document.getElementById('logout-btn'),
    
    // Room Details
    roomStatus: document.getElementById('room-status'),
    roomNumber: document.getElementById('room-number'),
    roomBlock: document.getElementById('room-block'),
    roomFloor: document.getElementById('room-floor'),
    bedNumber: document.getElementById('bed-number'),
    roomType: document.getElementById('room-type'),
    roomOccupancy: document.getElementById('room-occupancy'),
    
    // Facilities
    facilitiesGrid: document.getElementById('facilities-grid')
};

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

/**
 * Get authentication token
 * @returns {string|null}
 */
function getAuthToken() {
    return localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
}

/**
 * Get student ID
 * @returns {string|null}
 */
function getStudentId() {
    return localStorage.getItem('studentId') || sessionStorage.getItem('studentId');
}

/**
 * Set student ID
 * @param {string} studentId
 */
function setStudentId(studentId) {
    localStorage.setItem('studentId', studentId);
}

/**
 * Set auth token
 * @param {string} token
 */
function setAuthToken(token) {
    localStorage.setItem('authToken', token);
}

/**
 * Show loading state
 */
function showLoading() {
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.classList.add('loading');
    }
}

/**
 * Hide loading state
 */
function hideLoading() {
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.classList.remove('loading');
    }
}

// ==========================================
// API FUNCTIONS
// ==========================================

/**
 * Fetch room details from database
 * 
 * Expected API Response Format:
 * {
 *   success: true,
 *   data: {
 *     studentId: "STU001",
 *     roomNumber: "001 - B",
 *     block: "Block A",
 *     floor: "2nd Floor",
 *     bedNumber: "Bed 2",
 *     roomType: "Double Sharing",
 *     capacity: 2,
 *     occupied: 2,
 *     occupancy: "2/2 student",
 *     status: "Active"
 *   }
 * }
 * 
 * @param {string} studentId
 * @returns {Promise<Object>}
 */
async function fetchRoomDetails(studentId) {
    try {
        const response = await fetch(`${DB_CONFIG.apiUrl}${DB_CONFIG.endpoints.getRoomDetails}/${studentId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Room Details Response:', result);
        
        // Handle different response formats
        const data = result.data || result;
        
        // Store room data
        currentRoomData = {
            studentId: data.studentId || studentId,
            roomNumber: data.roomNumber || data.room_number || 'N/A',
            block: data.block || 'N/A',
            floor: data.floor || 'N/A',
            bedNumber: data.bedNumber || data.bed_number || 'N/A',
            roomType: data.roomType || data.room_type || 'N/A',
            capacity: data.capacity || 0,
            occupied: data.occupied || 0,
            occupancy: data.occupancy || `${data.occupied || 0}/${data.capacity || 0} student`,
            status: data.status || 'Active',
            facilities: data.facilities || []
        };
        
        return currentRoomData;
        
    } catch (error) {
        console.error('Error fetching room details:', error);
        
        // Return mock data for demo
        return {
            studentId: studentId,
            roomNumber: '001 - B',
            block: 'Block A',
            floor: '2nd Floor',
            bedNumber: 'Bed 2',
            roomType: 'Double Sharing',
            capacity: 2,
            occupied: 2,
            occupancy: '2/2 student',
            status: 'Active',
            facilities: []
        };
    }
}

/**
 * Fetch room facilities from database
 * 
 * Expected API Response Format:
 * {
 *   success: true,
 *   data: {
 *     roomNumber: "001 - B",
 *     facilities: [
 *       {
 *         id: 1,
 *         name: "Air condition",
 *         icon: "❄️",
 *         available: true
 *       },
 *       {
 *         id: 2,
 *         name: "Wi-Fi",
 *         icon: "📶",
 *         available: true
 *       },
 *       {
 *         id: 3,
 *         name: "Study Lamp",
 *         icon: "💡",
 *         available: true
 *       },
 *       {
 *         id: 4,
 *         name: "Wardrobe",
 *         icon: "🚪",
 *         available: true
 *       },
 *       {
 *         id: 5,
 *         name: "Study Table",
 *         icon: "📚",
 *         available: true
 *       },
 *       {
 *         id: 6,
 *         name: "Power Outlets",
 *         icon: "🔌",
 *         available: true
 *       }
 *     ]
 *   }
 * }
 * 
 * @param {string} studentId
 * @returns {Promise<Object>}
 */
async function fetchRoomFacilities(studentId) {
    try {
        const response = await fetch(`${DB_CONFIG.apiUrl}${DB_CONFIG.endpoints.getRoomFacilities}/${studentId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Room Facilities Response:', result);
        
        // Handle different response formats
        const data = result.data || result;
        
        // Normalize facilities array
        const facilities = (data.facilities || []).map(facility => ({
            id: facility.id || facility.facility_id,
            name: facility.name || facility.facility_name,
            icon: facility.icon || '📦',
            available: facility.available !== false
        }));
        
        return {
            roomNumber: data.roomNumber || data.room_number,
            facilities: facilities
        };
        
    } catch (error) {
        console.error('Error fetching room facilities:', error);
        
        // Return default facilities for demo
        return {
            roomNumber: currentRoomData.roomNumber,
            facilities: [
                { id: 1, name: 'Air condition', icon: '❄️', available: true },
                { id: 2, name: 'Wi-Fi', icon: '📶', available: true },
                { id: 3, name: 'Study Lamp', icon: '💡', available: true },
                { id: 4, name: 'Wardrobe', icon: '🚪', available: true },
                { id: 5, name: 'Study Table', icon: '📚', available: true },
                { id: 6, name: 'Power Outlets', icon: '🔌', available: true }
            ]
        };
    }
}

// ==========================================
// UI UPDATE FUNCTIONS
// ==========================================

/**
 * Update room details display
 * All room information changes based on student's assigned room from database
 * @param {Object} roomData - Room details from database
 */
function updateRoomDetails(roomData) {
    // Update Status Badge
    if (elements.roomStatus) {
        elements.roomStatus.textContent = roomData.status || 'Active';
        
        // Change badge color based on status
        if (roomData.status && roomData.status.toLowerCase() === 'inactive') {
            elements.roomStatus.classList.add('inactive');
        } else {
            elements.roomStatus.classList.remove('inactive');
        }
    }
    
    // Update Room Number - Changes for each student
    if (elements.roomNumber) {
        elements.roomNumber.textContent = roomData.roomNumber || 'N/A';
    }
    
    // Update Block - Changes based on room location
    if (elements.roomBlock) {
        elements.roomBlock.textContent = roomData.block || 'N/A';
    }
    
    // Update Floor - Changes based on room location
    if (elements.roomFloor) {
        elements.roomFloor.textContent = roomData.floor || 'N/A';
    }
    
    // Update Bed Number - Unique to each student
    if (elements.bedNumber) {
        elements.bedNumber.textContent = roomData.bedNumber || 'N/A';
    }
    
    // Update Room Type - Changes based on room configuration
    if (elements.roomType) {
        elements.roomType.textContent = roomData.roomType || 'N/A';
    }
    
    // Update Occupancy - Changes based on current room occupancy
    if (elements.roomOccupancy) {
        elements.roomOccupancy.textContent = roomData.occupancy || 'N/A';
    }
}

/**
 * Update room facilities display
 * Facilities load from database for each room
 * @param {Array} facilities - Array of facility objects from database
 */
function updateRoomFacilities(facilities) {
    if (!elements.facilitiesGrid) return;
    
    elements.facilitiesGrid.innerHTML = '';
    
    if (!facilities || facilities.length === 0) {
        elements.facilitiesGrid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 30px; color: #9ca3af;">
                No facilities information available
            </div>
        `;
        return;
    }
    
    // Create facility items from database data
    facilities.forEach(facility => {
        const facilityItem = document.createElement('div');
        facilityItem.className = 'facility-item';
        facilityItem.setAttribute('data-facility-id', facility.id);
        
        // If facility is not available, show with different style
        if (!facility.available) {
            facilityItem.style.opacity = '0.5';
        }
        
        facilityItem.innerHTML = `
            <div class="facility-icon">${facility.icon}</div>
            <div class="facility-name">${facility.name}</div>
        `;
        
        elements.facilitiesGrid.appendChild(facilityItem);
    });
}

// ==========================================
// LOAD DATA
// ==========================================

/**
 * Load all room information from database
 * Fetches student's specific room details and facilities
 */
async function loadRoomInformation() {
    const studentId = getStudentId();
    
    if (!studentId) {
        console.error('No student ID found');
        alert('Please login again');
        // window.location.href = '/login.html';
        return;
    }
    
    console.log('Loading room information for student:', studentId);
    showLoading();
    
    try {
        // Fetch room details and facilities in parallel
        const [roomDetails, roomFacilities] = await Promise.all([
            fetchRoomDetails(studentId),
            fetchRoomFacilities(studentId)
        ]);
        
        // Update UI with fetched data
        updateRoomDetails(roomDetails);
        updateRoomFacilities(roomFacilities.facilities);
        
        // Store facilities in current room data
        currentRoomData.facilities = roomFacilities.facilities;
        
        console.log('Room information loaded successfully');
        console.log('Current Room Data:', currentRoomData);
        
    } catch (error) {
        console.error('Error loading room information:', error);
        alert('Error loading room data. Please try again.');
    } finally {
        hideLoading();
    }
}

/**
 * Refresh room information
 * Reloads all room data from database
 */
async function refreshRoomInfo() {
    console.log('Refreshing room information...');
    await loadRoomInformation();
}

// ==========================================
// EVENT HANDLERS
// ==========================================

/**
 * Handle logout
 */
async function handleLogout(e) {
    e.preventDefault();
    
    const confirmLogout = confirm('Are you sure you want to logout?');
    if (!confirmLogout) return;
    
    try {
        // Call logout API
        await fetch(`${DB_CONFIG.apiUrl}${DB_CONFIG.endpoints.logout}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });
    } catch (error) {
        console.error('Logout API error:', error);
    }
    
    // Clear all stored data
    localStorage.clear();
    sessionStorage.clear();
    
    // Reset current room data
    currentRoomData = {
        studentId: null,
        roomNumber: null,
        block: null,
        floor: null,
        bedNumber: null,
        roomType: null,
        capacity: null,
        occupied: null,
        occupancy: null,
        status: null,
        facilities: []
    };
    
    // Redirect to login
    window.location.href = '/login.html';
}

// ==========================================
// EVENT LISTENERS
// ==========================================

/**
 * Initialize event listeners
 */
function initEventListeners() {
    // Logout button
    if (elements.logoutBtn) {
        elements.logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Navigation links
    
}

// ==========================================
// INITIALIZATION
// ==========================================

/**
 * Initialize the room information page
 */
async function init() {
    console.log('Initializing room information page...');
    
    // Check authentication
    const studentId = getStudentId();
    const authToken = getAuthToken();
    
    if (!studentId || !authToken) {
        console.warn('No authentication found');
        
        // Uncomment for production - redirect to login
        // window.location.href = '/login.html';
        
        // For demo/testing purposes only
        setStudentId('STU001');
        setAuthToken('demo_token_12345');
        console.log('Using demo credentials');
    }
    
    DB_CONFIG.studentId = getStudentId();
    
    // Initialize event listeners
    initEventListeners();
    
    // Load room data from database
    await loadRoomInformation();
    
    console.log('Room information page initialized successfully');
}

// ==========================================
// START APPLICATION
// ==========================================

// Wait for DOM to be fully loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// ==========================================
// EXPORT FUNCTIONS
// ==========================================

// Make functions available globally
window.refreshRoomInfo = refreshRoomInfo;
window.loadRoomInformation = loadRoomInformation;
window.getCurrentRoomData = () => currentRoomData;