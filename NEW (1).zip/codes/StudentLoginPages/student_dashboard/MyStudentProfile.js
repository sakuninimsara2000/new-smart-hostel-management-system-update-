// ==========================================
// DATABASE CONFIGURATION
// ==========================================
const DB_CONFIG = {
    apiUrl: 'http://your-api-endpoint.com/api',
    studentId: null,
    endpoints: {
        getStudentProfile: '/student/profile',
        updateStudentProfile: '/student/profile/update',
        uploadProfilePicture: '/student/profile/picture',
        logout: '/auth/logout'
    }
};

// ==========================================
// STUDENT PROFILE DATA STORAGE
// ==========================================
let currentProfileData = {
    studentId: null,
    firstName: null,
    lastName: null,
    fullName: null,
    dateOfBirth: null,
    email: null,
    address: null,
    gender: null,
    phoneNumber: null,
    emergencyNumber: null,
    year: null,
    department: null,
    faculty: null,
    regDate: null,
    expiredDate: null,
    profilePicture: null
};

// ==========================================
// DOM ELEMENTS
// ==========================================
const elements = {
    // Navigation
    navDashboard: document.getElementById('nav-dashboard'),
    navAttendance: document.getElementById('nav-attendance'),
    navRoom: document.getElementById('nav-room'),
    navSetting: document.getElementById('nav-setting'),
    logoutBtn: document.getElementById('logout-btn'),
    
    // Header
    headerStudentName: document.getElementById('header-student-name'),
    
    // Form Fields
    profileForm: document.getElementById('profile-form'),
    firstName: document.getElementById('first-name'),
    lastName: document.getElementById('last-name'),
    dateOfBirth: document.getElementById('date-of-birth'),
    email: document.getElementById('email'),
    address: document.getElementById('address'),
    gender: document.getElementById('gender'),
    phoneNumber: document.getElementById('phone-number'),
    emergencyNumber: document.getElementById('emergency-number'),
    studentId: document.getElementById('student-id'),
    year: document.getElementById('year'),
    department: document.getElementById('department'),
    faculty: document.getElementById('faculty'),
    regDate: document.getElementById('reg-date'),
    expiredDate: document.getElementById('expired-date'),
    
    // Profile Picture
    profilePicture: document.getElementById('profile-picture'),
    profileImage: document.getElementById('profile-image'),
    profilePlaceholder: document.getElementById('profile-placeholder'),
    profileInitials: document.getElementById('profile-initials'),
    profileUpload: document.getElementById('profile-upload'),
    
    // Buttons
    saveButton: document.getElementById('save-button')
};

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

/**
 * Get authentication token
 * @returns {string|null}
 */
function getAuthToken() {
    return localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
}

/**
 * Get student ID
 * @returns {string|null}
 */
function getStudentId() {
    return localStorage.getItem('studentId') || sessionStorage.getItem('studentId');
}

/**
 * Set student ID
 * @param {string} studentId
 */
function setStudentId(studentId) {
    localStorage.setItem('studentId', studentId);
}

/**
 * Set auth token
 * @param {string} token
 */
function setAuthToken(token) {
    localStorage.setItem('authToken', token);
}

/**
 * Format date for input field (YYYY-MM-DD)
 * @param {string} dateString
 * @returns {string}
 */
function formatDateForInput(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
}

/**
 * Get initials from name
 * @param {string} firstName
 * @param {string} lastName
 * @returns {string}
 */
function getInitials(firstName, lastName) {
    const first = (firstName || '').charAt(0).toUpperCase();
    const last = (lastName || '').charAt(0).toUpperCase();
    return first + last || 'SP';
}

/**
 * Show loading state
 */
function showLoading() {
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.classList.add('loading');
    }
    if (elements.saveButton) {
        elements.saveButton.disabled = true;
        elements.saveButton.textContent = 'Saving...';
    }
}

/**
 * Hide loading state
 */
function hideLoading() {
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.classList.remove('loading');
    }
    if (elements.saveButton) {
        elements.saveButton.disabled = false;
        elements.saveButton.textContent = 'Save Changes';
    }
}

/**
 * Show success message
 * @param {string} message
 */
function showSuccessMessage(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    document.body.appendChild(successDiv);
    
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

// ==========================================
// API FUNCTIONS
// ==========================================

/**
 * Fetch student profile from database
 * This automatically loads all student information from dashboard
 * 
 * Expected API Response Format:
 * {
 *   success: true,
 *   data: {
 *     studentId: "STU001",
 *     firstName: "Kasun",
 *     lastName: "Perera",
 *     fullName: "Kasun Perera",
 *     dateOfBirth: "2000-05-15",
 *     email: "kasun@uni.lk",
 *     address: "123 Main St, Colombo",
 *     gender: "Male",
 *     phoneNumber: "0771234567",
 *     emergencyNumber: "0779876543",
 *     year: "2",
 *     department: "Computer Science",
 *     faculty: "Engineering",
 *     regDate: "2022-01-15",
 *     expiredDate: "2026-01-15",
 *     profilePicture: "https://example.com/profile.jpg"
 *   }
 * }
 * 
 * @param {string} studentId
 * @returns {Promise<Object>}
 */
async function fetchStudentProfile(studentId) {
    try {
        const response = await fetch(`${DB_CONFIG.apiUrl}${DB_CONFIG.endpoints.getStudentProfile}/${studentId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Student Profile Response:', result);
        
        // Handle different response formats
        const data = result.data || result;
        
        // Store profile data
        currentProfileData = {
            studentId: data.studentId || data.student_id || studentId,
            firstName: data.firstName || data.first_name || '',
            lastName: data.lastName || data.last_name || '',
            fullName: data.fullName || data.full_name || `${data.firstName || ''} ${data.lastName || ''}`.trim(),
            dateOfBirth: data.dateOfBirth || data.date_of_birth || '',
            email: data.email || '',
            address: data.address || '',
            gender: data.gender || '',
            phoneNumber: data.phoneNumber || data.phone_number || data.contact || '',
            emergencyNumber: data.emergencyNumber || data.emergency_number || data.emergency_contact || '',
            year: data.year || '',
            department: data.department || '',
            faculty: data.faculty || '',
            regDate: data.regDate || data.reg_date || data.registrationDate || '',
            expiredDate: data.expiredDate || data.expired_date || data.expiryDate || '',
            profilePicture: data.profilePicture || data.profile_picture || data.avatar || null
        };
        
        return currentProfileData;
        
    } catch (error) {
        console.error('Error fetching student profile:', error);
        
        // Return mock data for demo
        return {
            studentId: studentId,
            firstName: 'Student',
            lastName: 'Name',
            fullName: 'Student Name',
            dateOfBirth: '2000-01-01',
            email: 'student@example.com',
            address: '',
            gender: '',
            phoneNumber: '',
            emergencyNumber: '',
            year: '',
            department: '',
            faculty: '',
            regDate: '',
            expiredDate: '',
            profilePicture: null
        };
    }
}

/**
 * Update student profile in database
 * Saves all changes made by the student
 * 
 * @param {string} studentId
 * @param {Object} profileData
 * @returns {Promise<Object>}
 */
async function updateStudentProfile(studentId, profileData) {
    try {
        const response = await fetch(`${DB_CONFIG.apiUrl}${DB_CONFIG.endpoints.updateStudentProfile}/${studentId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getAuthToken()}`
            },
            body: JSON.stringify(profileData)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Update Profile Response:', result);
        
        return result;
        
    } catch (error) {
        console.error('Error updating student profile:', error);
        throw error;
    }
}

/**
 * Upload profile picture to server
 * @param {string} studentId
 * @param {File} file
 * @returns {Promise<Object>}
 */
async function uploadProfilePicture(studentId, file) {
    try {
        const formData = new FormData();
        formData.append('profilePicture', file);
        formData.append('studentId', studentId);
        
        const response = await fetch(`${DB_CONFIG.apiUrl}${DB_CONFIG.endpoints.uploadProfilePicture}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${getAuthToken()}`
            },
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Upload Picture Response:', result);
        
        return result;
        
    } catch (error) {
        console.error('Error uploading profile picture:', error);
        throw error;
    }
}

// ==========================================
// UI UPDATE FUNCTIONS
// ==========================================

/**
 * Populate form with student data
 * Automatically fills all fields with data from dashboard/database
 * @param {Object} profileData
 */
function populateForm(profileData) {
    // Update header with student name
    if (elements.headerStudentName) {
        elements.headerStudentName.textContent = profileData.fullName || 'Student Setting';
    }
    
    // Fill all form fields automatically from database
    if (elements.firstName) {
        elements.firstName.value = profileData.firstName || '';
    }
    
    if (elements.lastName) {
        elements.lastName.value = profileData.lastName || '';
    }
    
    if (elements.dateOfBirth) {
        elements.dateOfBirth.value = formatDateForInput(profileData.dateOfBirth);
    }
    
    if (elements.email) {
        elements.email.value = profileData.email || '';
    }
    
    if (elements.address) {
        elements.address.value = profileData.address || '';
    }
    
    if (elements.gender) {
        elements.gender.value = profileData.gender || '';
    }
    
    if (elements.phoneNumber) {
        elements.phoneNumber.value = profileData.phoneNumber || '';
    }
    
    if (elements.emergencyNumber) {
        elements.emergencyNumber.value = profileData.emergencyNumber || '';
    }
    
    if (elements.studentId) {
        elements.studentId.value = profileData.studentId || '';
    }
    
    if (elements.year) {
        elements.year.value = profileData.year || '';
    }
    
    if (elements.department) {
        elements.department.value = profileData.department || '';
    }
    
    if (elements.faculty) {
        elements.faculty.value = profileData.faculty || '';
    }
    
    if (elements.regDate) {
        elements.regDate.value = formatDateForInput(profileData.regDate);
    }
    
    if (elements.expiredDate) {
        elements.expiredDate.value = formatDateForInput(profileData.expiredDate);
    }
    
    // Update profile picture
    updateProfilePicture(profileData.profilePicture, profileData.firstName, profileData.lastName);
}

/**
 * Update profile picture display
 * @param {string} pictureUrl
 * @param {string} firstName
 * @param {string} lastName
 */
function updateProfilePicture(pictureUrl, firstName, lastName) {
    if (pictureUrl && elements.profileImage) {
        elements.profileImage.src = pictureUrl;
        elements.profileImage.style.display = 'block';
        if (elements.profilePlaceholder) {
            elements.profilePlaceholder.style.display = 'none';
        }
    } else {
        if (elements.profileImage) {
            elements.profileImage.style.display = 'none';
        }
        if (elements.profilePlaceholder) {
            elements.profilePlaceholder.style.display = 'flex';
        }
        if (elements.profileInitials) {
            elements.profileInitials.textContent = getInitials(firstName, lastName);
        }
    }
}

/**
 * Get form data
 * Collects all data from form fields
 * @returns {Object}
 */
function getFormData() {
    return {
        firstName: elements.firstName?.value || '',
        lastName: elements.lastName?.value || '',
        dateOfBirth: elements.dateOfBirth?.value || '',
        email: elements.email?.value || '',
        address: elements.address?.value || '',
        gender: elements.gender?.value || '',
        phoneNumber: elements.phoneNumber?.value || '',
        emergencyNumber: elements.emergencyNumber?.value || '',
        year: elements.year?.value || '',
        department: elements.department?.value || '',
        faculty: elements.faculty?.value || '',
        expiredDate: elements.expiredDate?.value || ''
    };
}

// ==========================================
// LOAD DATA
// ==========================================

/**
 * Load student profile data
 * Automatically loads all information from dashboard when page opens
 */
async function loadStudentProfile() {
    const studentId = getStudentId();
    
    if (!studentId) {
        console.error('No student ID found');
        alert('Please login again');
        // window.location.href = '/login.html';
        return;
    }
    
    console.log('Loading student profile for:', studentId);
    showLoading();
    
    try {
        // Fetch profile data from database
        const profileData = await fetchStudentProfile(studentId);
        
        // Automatically fill all form fields with database data
        populateForm(profileData);
        
        console.log('Student profile loaded successfully:', profileData.fullName);
        console.log('Current Profile Data:', currentProfileData);
        
    } catch (error) {
        console.error('Error loading student profile:', error);
        alert('Error loading profile data. Please try again.');
    } finally {
        hideLoading();
    }
}

// ==========================================
// EVENT HANDLERS
// ==========================================

/**
 * Handle profile picture upload
 */
function handleProfileUpload(e) {
    const file = e.target.files[0];
    
    if (!file) return;
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
        alert('File size must be less than 5MB');
        return;
    }
    
    // Preview image locally
    const reader = new FileReader();
    reader.onload = (e) => {
        updateProfilePicture(e.target.result, elements.firstName?.value, elements.lastName?.value);
    };
    reader.readAsDataURL(file);
    
    // Upload to server
    const studentId = getStudentId();
    if (studentId) {
        uploadProfilePicture(studentId, file)
            .then(result => {
                console.log('Profile picture uploaded successfully');
                showSuccessMessage('Profile picture updated successfully!');
            })
            .catch(error => {
                console.error('Error uploading profile picture:', error);
                alert('Error uploading profile picture. Please try again.');
            });
    }
}

/**
 * Handle form submission
 * Saves all changes to database
 */
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const studentId = getStudentId();
    
    if (!studentId) {
        alert('Please login again');
        return;
    }
    
    showLoading();
    
    try {
        // Get updated form data
        const formData = getFormData();
        
        // Update profile in database
        await updateStudentProfile(studentId, formData);
        
        // Update current profile data
        currentProfileData = { ...currentProfileData, ...formData };
        
        console.log('Profile updated successfully');
        showSuccessMessage('Profile updated successfully!');
        
        // Reload profile to get latest data
        setTimeout(() => {
            loadStudentProfile();
        }, 1000);
        
    } catch (error) {
        console.error('Error updating profile:', error);
        alert('Error updating profile. Please try again.');
    } finally {
        hideLoading();
    }
}

/**
 * Handle logout
 */
async function handleLogout(e) {
    e.preventDefault();
    
    const confirmLogout = confirm('Are you sure you want to logout?');
    if (!confirmLogout) return;
    
    try {
        await fetch(`${DB_CONFIG.apiUrl}${DB_CONFIG.endpoints.logout}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });
    } catch (error) {
        console.error('Logout API error:', error);
    }
    
    // Clear all data
    localStorage.clear();
    sessionStorage.clear();
    
    // Reset profile data
    currentProfileData = {
        studentId: null,
        firstName: null,
        lastName: null,
        fullName: null,
        dateOfBirth: null,
        email: null,
        address: null,
        gender: null,
        phoneNumber: null,
        emergencyNumber: null,
        year: null,
        department: null,
        faculty: null,
        regDate: null,
        expiredDate: null,
        profilePicture: null
    };
    
    window.location.href = '/login.html';
}

// ==========================================
// EVENT LISTENERS
// ==========================================

/**
 * Initialize event listeners
 */
function initEventListeners() {
    // Profile picture upload
    if (elements.profileUpload) {
        elements.profileUpload.addEventListener('change', handleProfileUpload);
    }
    
    // Form submission
    if (elements.profileForm) {
        elements.profileForm.addEventListener('submit', handleFormSubmit);
    }
    
    // Logout button
    if (elements.logoutBtn) {
        elements.logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Navigation links
    
}

// ==========================================
// INITIALIZATION
// ==========================================

/**
 * Initialize the student profile page
 * Automatically loads all student data when page opens
 */
async function init() {
    console.log('Initializing student profile page...');
    
    // Check authentication
    const studentId = getStudentId();
    const authToken = getAuthToken();
    
    if (!studentId || !authToken) {
        console.warn('No authentication found');
        
        // Uncomment for production
        // window.location.href = '/login.html';
        
        // For demo/testing
        setStudentId('STU001');
        setAuthToken('demo_token_12345');
        console.log('Using demo credentials');
    }
    
    DB_CONFIG.studentId = getStudentId();
    
    // Initialize event listeners
    initEventListeners();
    
    // Automatically load student profile from database
    await loadStudentProfile();
    
    console.log('Student profile page initialized successfully');
}

// ==========================================
// START APPLICATION
// ==========================================

// Wait for DOM to be fully loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// ==========================================
// EXPORT FUNCTIONS
// ==========================================

// Make functions available globally
window.loadStudentProfile = loadStudentProfile;
window.getCurrentProfileData = () => currentProfileData;