import { auth, db } from "./firebase.js";
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";

// Form elements
const loginForm = document.getElementById("loginForm");
const alertBox = document.getElementById("alertBox");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const loginAsSelect = document.getElementById("loginAs");
const submitBtn = loginForm.querySelector('button[type="submit"]');

// Alert function
function showAlert(message, type) {
  alertBox.textContent = message;
  alertBox.className = `alert alert-${type}`;
  alertBox.style.display = "block";

  setTimeout(() => {
    alertBox.style.display = "none";
  }, 4000);
}

// Show loading state
function setLoading(loading) {
  if (loading) {
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;
  } else {
    submitBtn.classList.remove('loading');
    submitBtn.disabled = false;
  }
}

// Login submit
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();
  const loginAs = loginAsSelect.value;

  // Basic validation
  if (!email) {
    showAlert("Please Enter Email / University ID", "error");
    emailInput.focus();
    return;
  }

  if (!password) {
    showAlert("Please Enter Password", "error");
    passwordInput.focus();
    return;
  }

  setLoading(true);

  try {
    // Firebase Authentication
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    console.log("Logged in user:", user.email);

    // Firestore එකෙන් user data check කරනවා
    const userDoc = await getDoc(doc(db, "users", user.uid));
    
    if (!userDoc.exists()) {
      showAlert("User profile not found. Please contact admin.", "error");
      setLoading(false);
      return;
    }
    
    const userData = userDoc.data();
    
    // Check if user role matches selected login type
    if (userData.role !== loginAs) {
      showAlert(`This account is not registered as ${loginAs}`, "error");
      setLoading(false);
      return;
    }

    showAlert(`Login successful as ${loginAs}!`, "success");
    
    // Save to session storage
    sessionStorage.setItem('userId', user.uid);
    sessionStorage.setItem('userEmail', user.email);
    sessionStorage.setItem('userRole', loginAs);

    // Redirect by role
    setTimeout(() => {
      if (loginAs === "student") {
        window.location.href = "MyDashboard.html";
      } 
      else if (loginAs === "admin") {
        window.location.href = "adminDashboard.html";
      } 
      else if (loginAs === "warden") {
        window.location.href = "wardenDashboard.html";
      }
    }, 1500);

  } catch (error) {
    console.error(error);
    setLoading(false);

    // Friendly error messages
    if (error.code === "auth/user-not-found") {
      showAlert("User account does not exist", "error");
    } 
    else if (error.code === "auth/wrong-password") {
      showAlert("Password is incorrect", "error");
    }
    else if (error.code === "auth/invalid-email") {
      showAlert("Please enter a valid email address", "error");
    }
    else if (error.code === "auth/invalid-credential") {
      showAlert("Invalid email or password", "error");
    }
    else {
      showAlert(error.message, "error");
    }
  }
});