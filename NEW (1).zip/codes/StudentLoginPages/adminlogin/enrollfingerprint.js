import { db, auth } from "./firebase.js";
import {
  doc,
  setDoc,
  onSnapshot,
  getDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";

// ─── AUTH GUARD 
onAuthStateChanged(auth, (user) => {
  if (!user) window.location.href = "adminlogin.html";
});

// ─── FIRESTORE COMMAND DOC 
// ESP32 watches: enrollmentCommand/enroll
const COMMAND_DOC = doc(db, "enrollmentCommand", "enroll");

// ─── UI ELEMENTS 
const studentIdInput   = document.getElementById("studentId");
const studentNameInput = document.getElementById("studentName");
const enrollBtn        = document.getElementById("enrollBtn");
const statusDot        = document.getElementById("statusDot");
const statusText       = document.getElementById("statusText");
const scannerArea      = document.getElementById("scannerArea");
const scanIcon         = document.getElementById("scanIcon");
const scanLabel        = document.getElementById("scanLabel");
const scanSub          = document.getElementById("scanSub");

let unsubscribeListener = null;

// ─── ENROLL BUTTON ───────────────────────────────────────────
enrollBtn.addEventListener("click", async () => {
  const studentId   = studentIdInput.value.trim();
  const studentName = studentNameInput.value.trim();

  if (!studentId || !studentName) {
    showStatus("error", "Please enter Student ID and Name.");
    return;
  }

  // Check student exists in Firestore
  const studentSnap = await getDoc(doc(db, "students", studentId));
  if (!studentSnap.exists()) {
    showStatus("error", `Student ID "${studentId}" not found.`);
    return;
  }

  enrollBtn.disabled  = true;
  enrollBtn.innerHTML = "Enrolling...";
  showStatus("ready", "Sending command to scanner...");
  setScannerUI("waiting");

  try {
    // Write pending command — ESP32 is watching this
    await setDoc(COMMAND_DOC, {
      studentId,
      studentName,
      status:        "pending",
      fingerprintId: null,
      timestamp:     serverTimestamp()
    });

    showStatus("ready", "Waiting for ESP32 scanner...");
    startListening(studentId);

  } catch (err) {
    console.error(err);
    showStatus("error", "Failed to send command. Check connection.");
    resetUI();
  }
});

// ─── LISTEN FOR ESP32 RESPONSE ───────────────────────────────
function startListening(studentId) {
  if (unsubscribeListener) unsubscribeListener();

  // 30 second timeout
  const timeout = setTimeout(() => {
    if (unsubscribeListener) unsubscribeListener();
    showStatus("error", "Scanner timeout. Please try again.");
    resetUI();
  }, 30000);

  unsubscribeListener = onSnapshot(COMMAND_DOC, async (snapshot) => {
    if (!snapshot.exists()) return;
    const data = snapshot.data();

    if (data.status === "scanning") {
      clearTimeout(timeout);
      showStatus("ready", "Scanning... keep finger on sensor.");
      setScannerUI("scanning");

    } else if (data.status === "success") {
      clearTimeout(timeout);
      unsubscribeListener();
      showStatus("success", `Enrolled! Fingerprint ID: ${data.fingerprintId}`);
      setScannerUI("success");
      await saveToStudent(studentId, data.fingerprintId);
      setTimeout(() => resetUI(), 3000);

    } else if (data.status === "failed") {
      clearTimeout(timeout);
      unsubscribeListener();
      showStatus("error", "Scan failed. Please try again.");
      setScannerUI("failed");
      resetUI();
    }
  });
}

// ─── SAVE FINGERPRINT ID TO STUDENT RECORD ───────────────────
async function saveToStudent(studentId, fingerprintId) {
  try {
    await setDoc(doc(db, "students", studentId), {
      fingerprintId,
      enrolledAt: serverTimestamp()
    }, { merge: true });
  } catch (err) {
    console.error("Failed to save fingerprintId:", err);
    showStatus("error", "Enrolled but failed to save to student record.");
  }
}

// ─── UI HELPERS ──────────────────────────────────────────────
function showStatus(type, message) {
  statusText.textContent = message;
  statusDot.className    = "status-dot";
  if (type === "ready")   statusDot.classList.add("ready");
  if (type === "success") statusDot.classList.add("success");
  if (type === "error")   statusDot.classList.add("error");
}

function setScannerUI(state) {
  scannerArea.className = "scanner-area";
  if (state === "waiting") {
    scanIcon.style.color  = "#facc15";
    scanLabel.textContent = "Waiting for scanner...";
    scanSub.textContent   = "ESP32 is connecting";
  } else if (state === "scanning") {
    scannerArea.classList.add("scanning");
    scanIcon.style.color  = "#1abc9c";
    scanLabel.textContent = "Scanning fingerprint...";
    scanSub.textContent   = "Keep your finger on the sensor";
  } else if (state === "success") {
    scannerArea.classList.add("scanning");
    scanIcon.style.color  = "#22c55e";
    scanLabel.textContent = "Fingerprint Enrolled!";
    scanSub.textContent   = "Successfully saved";
  } else if (state === "failed") {
    scanIcon.style.color  = "#ef4444";
    scanLabel.textContent = "Scan failed";
    scanSub.textContent   = "Please try again";
  }
}

function resetUI() {
  enrollBtn.disabled    = false;
  enrollBtn.innerHTML   = '<i class="fas fa-fingerprint"></i> Enroll Fingerprint';
  scanIcon.style.color  = "";
  scanLabel.textContent = "Place finger on scanner";
  scanSub.textContent   = "Press Enroll Fingerprint to begin";
  scannerArea.className = "scanner-area";
  showStatus("ready", "Ready to scan");
  if (unsubscribeListener) { unsubscribeListener(); unsubscribeListener = null; }
}