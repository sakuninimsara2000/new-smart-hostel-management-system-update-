import { db } from "./firebase.js";
import {
  collection,
  addDoc,
  doc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";
// Listen for ESP32 fingerprint scan
onSnapshot(doc(db, "system_state", "latest_scan"), async (snapshot) => {
  if (!snapshot.exists()) return;

  const biometricId = snapshot.data().biometric_id;
  if (!biometricId) return;

  // 1️⃣ Check if student is registered
  const studentQuery = query(
    collection(db, "STUDENT"),
    where("Biometric_id", "==", biometricId)
  );

  const studentSnap = await getDocs(studentQuery);

  if (studentSnap.empty) {
    // ❌ Student NOT registered → show "checkin unsuccessful"
    showScreen("checkin-unsuccess");
    setTimeout(() => showScreen("scan-view"), 4000);
    return;
  }

  const studentDoc = studentSnap.docs[0];
  const studentData = studentDoc.data();
  const studentId = studentDoc.id;

  // 2️⃣ Get last attendance record
  const attendanceQuery = query(
    collection(db, "ATTENDANCE"),
    where("Student_id", "==", studentId),
    orderBy("Timestamp", "desc"),
    limit(1)
  );

  const attendanceSnap = await getDocs(attendanceQuery);
  const now = new Date();

  // 3️⃣ Decide whether to check-in
  if (attendanceSnap.empty || attendanceSnap.docs[0].data().Attendance_status === "Checked Out") {
    // Student either first time or last status was Checked Out → Check-in
    await addDoc(collection(db, "ATTENDANCE"), {
      Student_id: studentId,
      Attendance_status: "Checked In",
      Date: now.toLocaleDateString(),
      Time_in: now.toLocaleTimeString(),
      Timestamp: now
    });

    // Show check-in successful screen
    populateCheckinScreen(studentData, studentId, now);
  } else {
    // Student already checked in → show message or return to scan
    alert("Student already checked in!");
    showScreen("scan-view");
  }
});

// Show / hide screens
function showScreen(screenId) {
  const screens = [
    "scan-view",
    "checkout-success",
    "checkout-unsuccess",
    "checkin-success",
    "checkin-unsuccess"
  ];

  screens.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "none";
  });

  const screen = document.getElementById(screenId);
  if (screen) screen.style.display = "block";
}

// Populate check-in success screen with student details using IDs
function populateCheckinScreen(studentData, studentId, now) {
  showScreen("checkin-success");

  document.getElementById("full-name").innerText = `${studentData.Student_firstname} ${studentData.Student_lastname}`;
  document.getElementById("room-number").innerText = studentData.Room_id || "-";
  document.getElementById("year").innerText = studentData.Academic_year || "-";
  document.getElementById("student-id").innerText = studentId;
  document.getElementById("floor").innerText = studentData.Floor || "-";
  document.getElementById("faculty").innerText = studentData.Faculty || "-";

  document.getElementById("date-span").innerText = now.toLocaleDateString("en-US", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  document.getElementById("time-span").innerText = now.toLocaleTimeString();

  // Auto return to scan screen after 4 seconds
  setTimeout(() => showScreen("scan-view"), 4000);
}
