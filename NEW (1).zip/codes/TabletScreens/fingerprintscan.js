console.log("Fingerprint scan page loaded");

import { db } from "./firebase.js";

import {
  doc,
  onSnapshot,
  collection,
  query,
  where,
  getDocs,
  addDoc,
  orderBy,
  limit
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";

/* 🔹 Listen for fingerprint scan (from ESP32) */
onSnapshot(doc(db, "system_state", "latest_scan"), async (snapshot) => {

  if (!snapshot.exists()) return;

  const biometricId = snapshot.data().biometric_id;
  if (!biometricId) return;

  /* 🔹 Check STUDENT registration */
  const studentQuery = query(
    collection(db, "STUDENT"),
    where("Biometric_id", "==", biometricId)
  );

  const studentSnap = await getDocs(studentQuery);

  /* ❌ Unregistered student */
  if (studentSnap.empty) {
    moveToScreen("checkout-unsuccess");
    return;
  }

  const studentId = studentSnap.docs[0].id;

  /* 🔹 Get last attendance record */
  const attendanceQuery = query(
    collection(db, "ATTENDANCE"),
    where("Student_id", "==", studentId),
    orderBy("Timestamp", "desc"),
    limit(1)
  );

  const attendanceSnap = await getDocs(attendanceQuery);

  /* 🔹 First time → Check-in */
  if (attendanceSnap.empty) {
    await checkIn(studentId);
    moveToScreen("checkin-success");
    return;
  }

  const lastStatus = attendanceSnap.docs[0].data().Attendance_status;

  /* 🔹 Decision logic */
  if (lastStatus === "Checked In") {
    await checkOut(studentId);
    moveToScreen("checkout-success");
  } else {
    await checkIn(studentId);
    moveToScreen("checkin-success");
  }
});

/* 🔹 Check-in function */
async function checkIn(studentId) {
  await addDoc(collection(db, "ATTENDANCE"), {
    Student_id: studentId,
    Attendance_status: "Checked In",
    Date: new Date().toLocaleDateString(),
    Time_in: new Date().toLocaleTimeString(),
    Timestamp: new Date()
  });
}

/* 🔹 Check-out function */
async function checkOut(studentId) {
  await addDoc(collection(db, "ATTENDANCE"), {
    Student_id: studentId,
    Attendance_status: "Checked Out",
    Date: new Date().toLocaleDateString(),
    Time_out: new Date().toLocaleTimeString(),
    Timestamp: new Date()
  });
}

/* 🔹 Screen navigation + auto return */
function moveToScreen(screenId) {

  const screens = [
    "scan-view",
    "checkin-success",
    "checkout-success",
    "checkout-unsuccess"
  ];

  screens.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "none";
  });

  document.getElementById(screenId).style.display = "block";

  setTimeout(() => {
    screens.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = "none";
    });
    document.getElementById("scan-view").style.display = "block";
  }, 4000);
}