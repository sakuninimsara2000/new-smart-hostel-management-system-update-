import { db } from "./firebase.js";
import {
  doc,
  onSnapshot,
  collection,
  query,
  where,
  getDocs,
  addDoc,
  orderBy,
  limit
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";

// Listen for ESP32 fingerprint scan
onSnapshot(doc(db, "system_state", "latest_scan"), async (snapshot) => {
  if (!snapshot.exists()) return;

  const biometricId = snapshot.data().biometric_id;
  if (!biometricId) return;

  // 1️⃣ Check if student is registered
  const studentQuery = query(
    collection(db, "STUDENT"),
    where("Biometric_id", "==", biometricId)
  );

  const studentSnap = await getDocs(studentQuery);

  if (studentSnap.empty) {
    // ❌ Student NOT registered
    showScreen("checkout-unsuccess"); // Show Unsuccessful screen

    // Auto return to scan screen after 4 seconds
    setTimeout(() => {
      showScreen("scan-view");
    }, 4000);

    return;
  }

  // ✅ Student registered → handle check-in / check-out logic
  const studentDoc = studentSnap.docs[0];
  const studentData = studentDoc.data();
  const studentId = studentDoc.id;

  const attendanceQuery = query(
    collection(db, "ATTENDANCE"),
    where("Student_id", "==", studentId),
    orderBy("Timestamp", "desc"),
    limit(1)
  );

  const attendanceSnap = await getDocs(attendanceQuery);

  if (attendanceSnap.empty) {
    // First scan → Check-in
    await addDoc(collection(db, "ATTENDANCE"), {
      Student_id: studentId,
      Attendance_status: "Checked In",
      Date: new Date().toLocaleDateString(),
      Time_in: new Date().toLocaleTimeString(),
      Timestamp: new Date()
    });
    populateCheckoutSuccessScreen(studentData, studentId);
    return;
  }

  const lastStatus = attendanceSnap.docs[0].data().Attendance_status;

  if (lastStatus === "Checked In") {
    // Checked In → Check-out
    await addDoc(collection(db, "ATTENDANCE"), {
      Student_id: studentId,
      Attendance_status: "Checked Out",
      Date: new Date().toLocaleDateString(),
      Time_out: new Date().toLocaleTimeString(),
      Timestamp: new Date()
    });
    populateCheckoutSuccessScreen(studentData, studentId);
  } else {
    // Checked Out → Check-in
    await addDoc(collection(db, "ATTENDANCE"), {
      Student_id: studentId,
      Attendance_status: "Checked In",
      Date: new Date().toLocaleDateString(),
      Time_in: new Date().toLocaleTimeString(),
      Timestamp: new Date()
    });
    populateCheckoutSuccessScreen(studentData, studentId);
  }
});

// Show / hide screens
function showScreen(screenId) {
  const screens = [
    "scan-view",
    "checkout-success",
    "checkout-unsuccess"
  ];

  screens.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "none";
  });

  const screen = document.getElementById(screenId);
  if (screen) screen.style.display = "block";
}

// Populate checkout success screen with student details
function populateCheckoutSuccessScreen(studentData, studentId) {
  showScreen("checkout-success");

  document.querySelector(".student-detail1 p:nth-child(1)").innerHTML = `<strong>Full Name</strong> ${studentData.Student_firstname} ${studentData.Student_lastname}`;
  document.querySelector(".student-detail1 p:nth-child(2)").innerHTML = `<strong>Room Number</strong> ${studentData.Room_id || "-"}`;
  document.querySelector(".student-detail1 p:nth-child(3)").innerHTML = `<strong>Year</strong> ${studentData.Academic_year || "-"}`;

  document.querySelector(".student-detail2 p:nth-child(1)").innerHTML = `<strong>Student ID</strong> ${studentId}`;
  document.querySelector(".student-detail2 p:nth-child(2)").innerHTML = `<strong>Floor</strong> ${studentData.Floor || "-"}`;
  document.querySelector(".student-detail2 p:nth-child(3)").innerHTML = `<strong>Faculty</strong> ${studentData.Faculty || "-"}`;

  const timestampSpans = document.querySelectorAll(".timestamp span");
  const now = new Date();
  timestampSpans[0].innerText = now.toLocaleDateString("en-US", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  timestampSpans[1].innerText = now.toLocaleTimeString();

  // Handle reason form
  const reasonForm = document.querySelector(".reason-form");
  reasonForm.onsubmit = async (e) => {
    e.preventDefault();
    const reasonValue = document.getElementById("reason").value;

    await addDoc(collection(db, "ATTENDANCE"), {
      Student_id: studentId,
      Attendance_status: "Checked Out",
      Date: now.toLocaleDateString(),
      Time_out: now.toLocaleTimeString(),
      Reason: reasonValue,
      Timestamp: now
    });

    alert("Checkout Recorded Successfully!");
    showScreen("scan-view"); // return to scan page
  };
}
