import { db } from "./firebase.js";
import {
  collection,
  addDoc,
  doc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";

// Listen for ESP32 fingerprint scan
onSnapshot(doc(db, "system_state", "latest_scan"), async (snapshot) => {
  if (!snapshot.exists()) return;

  const scannedBiometricId = snapshot.data().biometric_id;
  if (!scannedBiometricId) return;

  // 1️⃣ Check if student is registered
  const studentQuery = query(
    collection(db, "STUDENT"),
    where("Biometric_id", "==", scannedBiometricId)
  );

  const studentSnap = await getDocs(studentQuery);

  if (studentSnap.empty) {
    // ❌ Student NOT registered → optionally redirect or show alert
    alert("Student not registered!");
    return;
  }

  const studentDoc = studentSnap.docs[0];
  const studentData = studentDoc.data();
  const studentId = studentDoc.id;

  // 2️⃣ Populate student details in HTML
  populateStudentDetails(studentData, studentId);

  // 3️⃣ Show checkout-success screen
  document.querySelector(".checkout-sucess").style.display = "block";

  // 4️⃣ Attach reason form submission
  const reasonForm = document.querySelector(".reason-form");
  reasonForm.onsubmit = async (e) => {
    e.preventDefault();

    const reasonValue = document.getElementById("reason").value;

    const now = new Date();

    // 5️⃣ Save attendance record
    await addDoc(collection(db, "ATTENDANCE"), {
      Student_id: studentId,
      Attendance_status: "Checked Out",
      Date: now.toLocaleDateString(),
      Time_out: now.toLocaleTimeString(),
      Reason: reasonValue,
      Timestamp: now
    });

    alert("Checkout Recorded Successfully!");
    window.location.reload(); // return to scan page
  };
});

// Populate student details dynamically using IDs
function populateStudentDetails(studentData, studentId) {
  document.getElementById("full-name").innerText = `${studentData.Student_firstname} ${studentData.Student_lastname}`;
  document.getElementById("room-number").innerText = studentData.Room_id || "-";
  document.getElementById("year").innerText = studentData.Academic_year || "-";
  document.getElementById("student-id").innerText = studentId;
  document.getElementById("floor").innerText = studentData.Floor || "-";
  document.getElementById("faculty").innerText = studentData.Faculty || "-";

  const now = new Date();
  document.getElementById("date-span").innerText = now.toLocaleDateString("en-US", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  document.getElementById("time-span").innerText = now.toLocaleTimeString();
}
